/* ==========================================================================
   Hafiz Cilik — app.js
   Vanilla JS, tanpa framework. Tiga hal yang paling menentukan di sini:
   1. SATU objek Audio yang dibuka pada sentuhan pertama, lalu hanya .src-nya
      yang diganti. Ini yang membuat "Putar semua" tidak diblokir Safari iOS.
   2. Daftar ayat dibangun dari data lokal, jadi langsung muncul tanpa jaringan.
      Teks Arab/latin/arti menyusul dan disimpan untuk pemakaian berikutnya.
   3. Semua state pemutar lewat satu pintu (stopAll) supaya tombol dan kartu
      tidak pernah menunjukkan keadaan yang berbeda dari audionya.
   ========================================================================== */
'use strict';

const AUDIO_CACHE = 'hafiz-audio-v1';
const REPEATS = [1, 3, 5, 10];
const GAPS = [0, 1, 2, 4];
const SPEEDS = [0.75, 0.9, 1, 1.15];
const $ = id => document.getElementById(id);

/* ---------- penyimpanan yang tidak pernah melempar error ---------- */
const store = {
  mem: {},
  get(k, fb) {
    try { const v = localStorage.getItem('hafiz:' + k); return v === null ? fb : JSON.parse(v); }
    catch (e) { return k in this.mem ? this.mem[k] : fb; }
  },
  set(k, v) {
    this.mem[k] = v;
    try { localStorage.setItem('hafiz:' + k, JSON.stringify(v)); } catch (e) { /* mode privat: cukup di memori */ }
  },
  del(k) {
    delete this.mem[k];
    try { localStorage.removeItem('hafiz:' + k); } catch (e) {}
  }
};

const state = {
  level: store.get('level', '1'),
  surah: null,
  verses: [],          // [{no, global, ar, latin, id}]
  repeat: store.get('repeat', 3),
  gap: store.get('gap', 1),
  speed: store.get('speed', 1),
  reciter: store.get('reciter', RECITERS[0].id),
  stars: store.get('stars', 0),
  saved: new Set(),    // nomor ayat global yang audionya sudah tersimpan
  playing: null,       // {idx, rep, target, chain}
  timer: null
};

/* ---------- audio: satu objek, dibuka sekali ---------- */
const SILENCE = 'data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEARKwAAIhYAQACABAAZGF0YQAAAAA=';
let audio = null;
let unlocked = false;

function makeAudio() {
  if (audio) return audio;
  audio = new Audio();
  audio.preload = 'auto';
  audio.crossOrigin = 'anonymous';
  audio.addEventListener('ended', onEnded);
  audio.addEventListener('error', onAudioError);
  return audio;
}

function unlock() {
  if (unlocked) return;
  unlocked = true;
  const a = makeAudio();
  a.src = SILENCE;
  const p = a.play();
  if (p && p.catch) p.catch(() => { /* akan dibuka lagi oleh ketukan berikutnya */ });
}
['pointerdown', 'keydown'].forEach(ev =>
  window.addEventListener(ev, unlock, { once: true, passive: true }));

/* ---------- utilitas ---------- */
function icon(id, cls) {
  return `<svg class="${cls || 'ico'}" aria-hidden="true"><use href="#${id}"></use></svg>`;
}
function esc(s) {
  return String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}
function toast(msg) {
  const t = $('toast');
  $('toastText').textContent = msg;
  t.classList.add('is-on');
  clearTimeout(toast._t);
  toast._t = setTimeout(() => t.classList.remove('is-on'), 2800);
}

/* ---------- langit bintang (elemen khas app ini) ---------- */
const SKY_SLOTS = 24;
function renderSky() {
  const sky = $('sky');
  const shown = state.stars % SKY_SLOTS;
  const moons = Math.floor(state.stars / SKY_SLOTS);
  sky.querySelectorAll('.sky__star').forEach(n => n.remove());
  for (let i = 0; i < shown; i++) {
    const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    s.setAttribute('class', 'sky__star');
    s.setAttribute('aria-hidden', 'true');
    // posisi ditentukan dari indeks, bukan acak, supaya bintang tidak berpindah
    s.style.left = (6 + ((i * 37) % 108)) + 'px';
    s.style.top = (7 + ((i * 19) % 34)) + 'px';
    s.style.animationDelay = (i % 7) * 0.3 + 's';
    s.innerHTML = '<use href="#i-star"></use>';
    sky.appendChild(s);
  }
  $('skyCount').textContent = state.stars;
  sky.setAttribute('aria-label',
    `Langit bintang, ${state.stars} bintang terkumpul` + (moons ? `, ${moons} langit penuh` : ''));
}
function addStar(n) {
  state.stars += n;
  store.set('stars', state.stars);
  renderSky();
  if (state.stars > 0 && state.stars % SKY_SLOTS === 0) toast('Langitmu penuh bintang! Masyaallah');
}

/* ---------- layar 1: daftar surah ---------- */
function renderLevels() {
  $('levels').innerHTML = LEVELS.map(l => `
    <button class="chip" type="button" data-level="${l.key}" aria-pressed="${l.key === state.level}">
      ${esc(l.label)} <small>${esc(l.hint)}</small>
    </button>`).join('');
}

function surahSaved(s) {
  for (let i = 0; i < s.n; i++) if (!state.saved.has(s.start + i)) return false;
  return s.n > 0;
}

function renderGrid() {
  const level = LEVELS.find(l => l.key === state.level) || LEVELS[0];
  const list = SURAHS.filter(level.test);
  const hafal = new Set(store.get('hafal', []));

  $('grid').innerHTML = list.map(s => `
    <button class="card card--${s.sky}" type="button" data-id="${s.id}">
      <span class="card__head">
        ${icon('s-' + s.sym, 'card__sym')}
        <span class="card__grow"></span>
        <span class="card__badges">
          ${hafal.has(s.id) ? `<span class="card__badge">${icon('i-check')}<span class="sr-only">Sudah pernah selesai</span></span>` : ''}
          ${surahSaved(s) ? `<span class="card__badge">${icon('i-saved')}<span class="sr-only">Tersimpan, bisa tanpa internet</span></span>` : ''}
        </span>
        <span class="card__no">${s.id}</span>
      </span>
      <span class="card__ar" dir="rtl" lang="ar">${esc(s.ar)}</span>
      <span class="card__name">${esc(s.name)}</span>
      <span class="card__meta">${s.n} AYAT</span>
      <span class="card__meaning">${esc(s.meaning)}</span>
    </button>`).join('');
}

/* ---------- layar 2: pemutar ---------- */
function openSurah(s) {
  stopAll();
  state.surah = s;
  state.verses = Array.from({ length: s.n }, (_, i) => ({ no: i + 1, global: s.start + i }));

  $('hero').className = 'hero card--' + s.sky;
  $('heroSym').innerHTML = `<use href="#s-${s.sym}"></use>`;
  $('heroAr').textContent = s.ar;
  $('heroName').textContent = s.name;
  $('heroMeta').textContent = `${s.n} ayat · ${s.meaning}`;

  renderSegs();
  renderVerses();
  updateSaveBtn();

  $('viewHome').classList.add('hidden');
  $('viewSurah').classList.remove('hidden');
  window.scrollTo({ top: 0, behavior: 'auto' });
  $('btnBack').focus();

  loadText(s);
}

function backHome() {
  stopAll();
  $('viewSurah').classList.add('hidden');
  $('viewHome').classList.remove('hidden');
  renderGrid();
  window.scrollTo({ top: 0, behavior: 'auto' });
}

function renderSegs() {
  $('segRepeat').innerHTML = REPEATS.map(r => `
    <button class="chip" type="button" data-repeat="${r}" aria-pressed="${r === state.repeat}">${r}×</button>`).join('');
  $('segGap').innerHTML = GAPS.map(g => `
    <button class="chip" type="button" data-gap="${g}" aria-pressed="${g === state.gap}">${g === 0 ? 'Tanpa' : g + ' dtk'}</button>`).join('');
  $('segSpeed').innerHTML = SPEEDS.map(v => `
    <button class="chip" type="button" data-speed="${v}" aria-pressed="${v === state.speed}">${v === 1 ? 'Normal' : v + '×'}</button>`).join('');
  const sum = $('tuneSum');
  if (sum) sum.textContent = `${state.repeat}× · ${state.gap === 0 ? 'tanpa jeda' : state.gap + ' dtk jeda'}`;
}

function renderVerses() {
  const hasText = state.verses.some(v => v.ar);
  const wrap = $('ayat');
  wrap.className = 'ayat' + (hasText ? ' ayat--full' : '');
  wrap.innerHTML = state.verses.map((v, i) => `
    <button class="ayah" type="button" data-idx="${i}" id="ayah${i}">
      <span class="ayah__no" aria-hidden="true">${v.no}</span>
      <span class="ayah__body">
        <span class="sr-only">Ayat ${v.no}. </span>
        ${v.ar ? `<span class="ayah__ar" dir="rtl" lang="ar">${esc(v.ar)}</span>` : ''}
        ${v.latin ? `<span class="ayah__latin">${esc(v.latin)}</span>` : ''}
        ${v.id ? `<span class="ayah__id">${esc(v.id)}</span>` : ''}
        <span class="ayah__status" data-status="${i}">${v.ar ? '' : 'Ketuk untuk dengar'}</span>
      </span>
      ${icon('i-play', 'ayah__cue')}
    </button>`).join('');
  // ganti isi cue jadi wadah supaya bisa ditukar ikonnya
  wrap.querySelectorAll('.ayah').forEach((el, i) => {
    const cue = el.querySelector('.ayah__cue');
    const box = document.createElement('span');
    box.className = 'ayah__cue';
    box.dataset.cue = i;
    box.innerHTML = icon('i-play');
    cue.replaceWith(box);
  });
}

/* ---------- teks ayat ---------- */
const EDITIONS = 'quran-uthmani,en.transliteration,id.indonesian';

async function loadText(s) {
  const cached = store.get('text:' + s.id, null);
  if (cached && cached.length === s.n) {
    applyText(cached);
    return;
  }
  setStatusAll('Mengambil teks ayat…');
  try {
    const res = await fetch(`https://api.alquran.cloud/v1/surah/${s.id}/editions/${EDITIONS}`);
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const json = await res.json();
    const eds = json.data;
    const byId = {};
    eds.forEach(e => { byId[e.edition.identifier] = e.ayahs; });
    const ar = byId['quran-uthmani'] || [];
    const tl = byId['en.transliteration'] || [];
    const id = byId['id.indonesian'] || [];

    // pemeriksaan silang: nomor global dari API harus sama dengan data lokal
    if (ar[0] && ar[0].number !== s.start) {
      console.warn('Nomor ayat global berbeda; memakai nomor dari API.', ar[0].number, s.start);
      state.verses.forEach((v, i) => { if (ar[i]) v.global = ar[i].number; });
    }

    const rows = state.verses.map((v, i) => ({
      ar: ar[i] ? ar[i].text : '',
      latin: tl[i] ? tl[i].text : '',
      id: id[i] ? id[i].text : ''
    }));
    store.set('text:' + s.id, rows);
    if (state.surah && state.surah.id === s.id) applyText(rows);
  } catch (e) {
    setStatusAll(navigator.onLine ? 'Teks belum bisa diambil — suaranya tetap bisa diputar'
                                  : 'Sedang tanpa internet — teks menyusul nanti');
  }
}

function applyText(rows) {
  state.verses.forEach((v, i) => {
    if (!rows[i]) return;
    v.ar = rows[i].ar; v.latin = rows[i].latin; v.id = rows[i].id;
  });
  const keep = state.playing ? state.playing.idx : null;
  renderVerses();
  if (keep !== null) paintPlaying(keep);
}

function setStatusAll(msg) {
  document.querySelectorAll('[data-status]').forEach(n => { n.textContent = msg; });
}

/* ---------- pemutar ---------- */
function cueOf(i) { return document.querySelector(`[data-cue="${i}"]`); }
function statusOf(i) { return document.querySelector(`[data-status="${i}"]`); }

function paintPlaying(i) {
  const el = $('ayah' + i);
  if (el) el.classList.add('is-on');
  const cue = cueOf(i);
  if (cue) cue.innerHTML = icon('i-pause');
  paintRepeat(i);
}

function paintRepeat(i) {
  const st = statusOf(i);
  if (!st || !state.playing) return;
  const { rep, target } = state.playing;
  let dots = '';
  if (target > 1) {
    dots = '<span class="rep-dots">' +
      Array.from({ length: Math.min(target, 10) }, (_, k) => `<i class="${k < rep ? 'on' : ''}"></i>`).join('') +
      '</span>';
  }
  st.innerHTML = `Sedang dibaca · ulangan ${rep}/${target}${dots}`;
}

function clearPaint(i) {
  const el = $('ayah' + i);
  if (el) el.classList.remove('is-on');
  const cue = cueOf(i);
  if (cue) cue.innerHTML = icon('i-play');
  const st = statusOf(i);
  if (st) st.textContent = state.verses[i] && state.verses[i].ar ? '' : 'Ketuk untuk dengar';
}

function stopAll() {
  clearTimeout(state.timer);
  state.timer = null;
  if (audio) { audio.pause(); audio.removeAttribute('src'); }
  if (state.playing) { clearPaint(state.playing.idx); state.playing = null; }
  updateAllBtn(false);
}

function playAyah(idx, chain) {
  if (state.playing && state.playing.idx === idx && !chain) { stopAll(); return; }
  const wasChain = chain === undefined ? (state.playing ? state.playing.chain : false) : chain;
  clearTimeout(state.timer);
  if (state.playing) clearPaint(state.playing.idx);

  state.playing = { idx, rep: 1, target: state.repeat, chain: !!wasChain };
  paintPlaying(idx);
  updateAllBtn(!!wasChain);
  start(idx);
  warm(idx + 1);
}

function start(idx) {
  const a = makeAudio();
  unlocked = true;
  a.src = audioUrl(state.reciter, state.verses[idx].global);
  a.playbackRate = state.speed;
  const p = a.play();
  if (p && p.catch) p.catch(err => {
    if (err && err.name === 'NotAllowedError') {
      const st = statusOf(idx);
      if (st) st.textContent = 'Ketuk sekali lagi untuk memulai suara';
    } else {
      onAudioError();
    }
  });
}

function onEnded() {
  const cur = state.playing;
  if (!cur) return;
  const gapMs = state.gap * 1000;

  if (cur.rep < cur.target) {
    cur.rep++;
    paintRepeat(cur.idx);
    state.timer = setTimeout(() => { if (state.playing === cur) start(cur.idx); }, gapMs);
    return;
  }

  addStar(1);

  if (cur.chain && cur.idx + 1 < state.verses.length) {
    const next = cur.idx + 1;
    clearPaint(cur.idx);
    state.timer = setTimeout(() => { if (state.playing === cur) playAyah(next, true); }, gapMs);
    return;
  }

  const finishedSurah = cur.chain;
  stopAll();
  if (finishedSurah) {
    addStar(5);
    markHafal(state.surah.id);
    toast(`Selesai satu surah! Kamu dapat 5 bintang`);
  }
}

function onAudioError() {
  const cur = state.playing;
  const idx = cur ? cur.idx : null;
  stopAll();
  if (idx !== null) {
    const st = statusOf(idx);
    if (st) st.textContent = navigator.onLine
      ? 'Suara gagal dimuat — coba qari lain di Pengaturan'
      : 'Suara ini belum tersimpan. Sambungkan internet dulu, lalu tekan tombol simpan.';
  }
}

/* muat awal ayat berikutnya supaya sambungannya mulus */
function warm(idx) {
  const v = state.verses[idx];
  if (!v) return;
  const url = audioUrl(state.reciter, v.global);
  fetch(url, { mode: 'cors' }).catch(() => fetch(url, { mode: 'no-cors' }).catch(() => {}));
}

function toggleAll() {
  if (state.playing && state.playing.chain) { stopAll(); return; }
  playAyah(0, true);
}

function updateAllBtn(on) {
  const b = $('btnAll');
  b.className = 'btn btn--big ' + (on ? 'btn--stop' : 'btn--go');
  b.querySelector('use').setAttribute('href', on ? '#i-stop' : '#i-play');
  $('btnAllText').textContent = on ? 'Berhenti' : 'Putar semua';
}

function markHafal(id) {
  const set = new Set(store.get('hafal', []));
  set.add(id);
  store.set('hafal', Array.from(set));
}

/* ---------- simpan audio untuk dipakai tanpa internet ---------- */
async function scanSaved() {
  state.saved = new Set();
  if (!('caches' in window)) return;
  try {
    const cache = await caches.open(AUDIO_CACHE);
    const keys = await cache.keys();
    keys.forEach(req => {
      const m = req.url.match(/\/(\d+)\.mp3$/);
      if (m && req.url.includes('/' + state.reciter + '/')) state.saved.add(+m[1]);
    });
  } catch (e) {}
}

async function saveSurah() {
  const s = state.surah;
  if (!('caches' in window)) { toast('Perangkat ini belum mendukung penyimpanan offline'); return; }
  const btn = $('btnSave');
  btn.disabled = true;
  $('saveMeter').classList.remove('hidden');

  const cache = await caches.open(AUDIO_CACHE);
  let done = 0, failed = 0;
  for (const v of state.verses) {
    const url = audioUrl(state.reciter, v.global);
    try {
      const hit = await cache.match(url);
      if (!hit) {
        let res;
        try { res = await fetch(url, { mode: 'cors' }); }
        catch (e) { res = await fetch(url, { mode: 'no-cors' }); }
        if (res && (res.ok || res.type === 'opaque')) await cache.put(url, res.clone());
        else failed++;
      }
      state.saved.add(v.global);
    } catch (e) { failed++; }
    done++;
    $('saveBar').style.width = Math.round(done / state.verses.length * 100) + '%';
  }

  btn.disabled = false;
  setTimeout(() => { $('saveMeter').classList.add('hidden'); $('saveBar').style.width = '0'; }, 700);
  updateSaveBtn();
  toast(failed ? `${state.verses.length - failed} dari ${state.verses.length} ayat tersimpan`
              : `Surah ${s.name} siap dipakai tanpa internet`);
  storageInfo();
}

function updateSaveBtn() {
  const s = state.surah;
  if (!s) return;
  const ok = surahSaved(s);
  const btn = $('btnSave');
  btn.querySelector('use').setAttribute('href', ok ? '#i-saved' : '#i-download');
  btn.title = ok ? 'Sudah tersimpan di perangkat' : 'Simpan untuk dipakai tanpa internet';
  btn.setAttribute('aria-label', btn.title);
}

async function storageInfo() {
  const el = $('storageInfo');
  if (!el) return;
  let txt = state.saved.size + ' ayat audio tersimpan';
  try {
    if (navigator.storage && navigator.storage.estimate) {
      const { usage } = await navigator.storage.estimate();
      txt += ' · ' + (usage / 1048576).toFixed(1) + ' MB terpakai';
    }
  } catch (e) {}
  el.textContent = txt;
}

/* ---------- panel pengaturan ---------- */
function renderReciters() {
  $('pickReciter').innerHTML = RECITERS.map(r => `
    <button class="pick__opt" type="button" role="radio" data-reciter="${r.id}"
            aria-checked="${r.id === state.reciter}">
      <b>${esc(r.name)}</b><span>${esc(r.note)}</span>
    </button>`).join('');
}

function openSheet() {
  renderReciters();
  renderSegs();
  storageInfo();
  $('sheet').classList.remove('hidden');
  $('btnCloseSheet').focus();
}
function closeSheet() {
  $('sheet').classList.add('hidden');
  $('btnSheet').focus();
}

/* ---------- kejadian ---------- */
document.addEventListener('click', async e => {
  const t = e.target.closest('button');
  if (!t) return;

  if (t.dataset.level) {
    state.level = t.dataset.level; store.set('level', state.level);
    renderLevels(); renderGrid(); return;
  }
  if (t.dataset.id) {
    const s = SURAHS.find(x => x.id === +t.dataset.id);
    if (s) openSurah(s);
    return;
  }
  if (t.dataset.idx !== undefined) { playAyah(+t.dataset.idx, false); return; }
  if (t.dataset.repeat) {
    state.repeat = +t.dataset.repeat; store.set('repeat', state.repeat);
    if (state.playing) { state.playing.target = state.repeat; paintRepeat(state.playing.idx); }
    renderSegs(); return;
  }
  if (t.dataset.gap !== undefined && t.dataset.gap !== '') {
    state.gap = +t.dataset.gap; store.set('gap', state.gap); renderSegs(); return;
  }
  if (t.dataset.speed) {
    state.speed = +t.dataset.speed; store.set('speed', state.speed);
    if (audio) audio.playbackRate = state.speed;
    renderSegs(); return;
  }
  if (t.dataset.reciter) {
    if (t.dataset.reciter !== state.reciter) {
      stopAll();
      state.reciter = t.dataset.reciter; store.set('reciter', state.reciter);
      await scanSaved(); renderReciters(); updateSaveBtn(); storageInfo();
      if (!state.surah) renderGrid();
      toast('Suara qari diganti');
    }
    return;
  }

  switch (t.id) {
    case 'btnTune': {
      const open = t.getAttribute('aria-expanded') === 'true';
      t.setAttribute('aria-expanded', String(!open));
      $('tune').classList.toggle('hidden', open);
      break;
    }
    case 'btnBack': backHome(); break;
    case 'btnAll': toggleAll(); break;
    case 'btnSave': saveSurah(); break;
    case 'btnSheet': openSheet(); break;
    case 'btnCloseSheet': closeSheet(); break;
    case 'btnClearAudio':
      if ('caches' in window) await caches.delete(AUDIO_CACHE);
      await scanSaved(); updateSaveBtn(); storageInfo(); renderGrid();
      toast('Audio tersimpan sudah dihapus');
      break;
    case 'btnResetStars':
      state.stars = 0; store.set('stars', 0); store.del('hafal');
      renderSky(); renderGrid(); toast('Bintang dimulai dari nol');
      break;
  }
});

$('sheet').addEventListener('click', e => { if (e.target.id === 'sheet') closeSheet(); });
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    if (!$('sheet').classList.contains('hidden')) closeSheet();
    else if (state.playing) stopAll();
  }
});
window.addEventListener('offline', () => toast('Tanpa internet — surah yang sudah disimpan tetap bisa diputar'));

/* ---------- pasang aplikasi ---------- */
let installEvent = null;
window.addEventListener('beforeinstallprompt', e => {
  e.preventDefault();
  installEvent = e;
  $('btnInstall').classList.remove('hidden');
});
$('btnInstall').addEventListener('click', async () => {
  if (!installEvent) return;
  installEvent.prompt();
  await installEvent.userChoice;
  installEvent = null;
  $('btnInstall').classList.add('hidden');
});

/* ---------- mulai ---------- */
(async function init() {
  renderSky();
  renderLevels();
  await scanSaved();
  renderGrid();
  if ('serviceWorker' in navigator && location.protocol.startsWith('http')) {
    navigator.serviceWorker.register('sw.js').catch(() => {});
  }
})();
